@extends('layouts.app')

@section('title') {{trans('general.our_events')}} -@endsection



@section('content')
<section class="section section-sm">
    <div class="container">

        <div class="row justify-content-center text-center mb-sm">
            <div class="col-lg-12 py-5">

                @if(Session::has('error'))
                <div class="alert alert-danger">
                    {{ Session::get('error') }}
                </div>

                @endif

                <h2 class="mb-0 text-break">{{trans('general.our_events')}}</h2>
                <p class="lead text-muted mt-0">

                </p>
                @if(Session::has('success'))
                <p>{{ Session::get('success') }}</p>
                @endif



            </div>
        </div>

        <div class="row">
            

            @foreach($events as $response)
            
            @php
            $user = DB::table('users')->where('id', '=', $response->user_id)->where('status', 'active')->first();
            @endphp
            
            <div class="col-md-4 mb-4">
                @include('includes.listing-events')
            </div>
            
            @endforeach
            
            

        </div>
        
        <!-- Share modal -->
        <div class="modal fade share-modal" id="share-event-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="mySmallModalLabel">{{trans('general.share')}}</h5>
                        <button type="button" class="close close-inherit" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"><i class="fa fa-times-circle"></i></span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-4 col-6 mb-3">
                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{url('events/'.$response->id)}}" id="facebook_href" title="Facebook" target="_blank" class="social-share text-muted d-block text-center h6">
                                        <i class="fab fa-facebook-square facebook-btn"></i>
                                        <span class="btn-block mt-3">Facebook</span>
                                    </a>
                                </div>
                                <div class="col-md-4 col-6 mb-3">
                                    <a href="https://twitter.com/intent/tweet?url={{url('events/'.$response->id)}}&text={{ e( $user->hide_name == 'yes' ? $user->username : $user->name ) }}" data-url="{{url('events/'.$response->id)}}" id="twitter_href" class="social-share text-muted d-block text-center h6" target="_blank" title="Twitter">
                                        <i class="fab fa-twitter twitter-btn"></i> <span class="btn-block mt-3">Twitter</span>
                                    </a>
                                </div>
                                <div class="col-md-4 col-6 mb-3">
                                    <a href="whatsapp://send?text={{url('events/'.$response->id)}}" data-action="share/whatsapp/share" id="whatsapp_href" class="social-share text-muted d-block text-center h6" title="WhatsApp">
                                        <i class="fab fa-whatsapp btn-whatsapp"></i> <span class="btn-block mt-3">WhatsApp</span>
                                    </a>
                                </div>

                                <div class="col-md-4 col-6 mb-3">
                                    <a href="mailto:?subject={{ e( $user->hide_name == 'yes' ? $user->username : $user->name ) }}&amp;body={{url('events/'.$response->id)}}" id="mail_href" class="social-share text-muted d-block text-center h6" title="{{trans('auth.email')}}">
                                        <i class="far fa-envelope"></i> <span class="btn-block mt-3">{{trans('auth.email')}}</span>
                                    </a>
                                </div>
                                <div class="col-md-4 col-6 mb-3">
                                    <a href="sms://?body={{ trans('general.check_this') }} {{url('events/'.$response->id)}}" id="sms_href" class="social-share text-muted d-block text-center h6" title="{{ trans('general.sms') }}">
                                        <i class="fa fa-sms"></i> <span class="btn-block mt-3">{{ trans('general.sms') }}</span>
                                    </a>
                                </div>
                                <div class="col-md-4 col-6 mb-3">
                                    <a href="javascript:void(0);" id="btn_copy_url" class="social-share text-muted d-block text-center h6 link-share" title="{{trans('general.copy_link')}}">
                                        <i class="fas fa-link"></i> <span class="btn-block mt-3">{{trans('general.copy_link')}}</span>
                                    </a>
                                    <input type="hidden" readonly="readonly" id="copy_link" class="form-control" value="{{url('events/'.$response->id)}}">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- Share modal end -->
        
        
    </div>
</section>
@endsection
