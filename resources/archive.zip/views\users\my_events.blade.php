@extends('layouts.app')

@section('title') {{trans('general.my_events')}} -@endsection

@section('javascript')
<!--<script type="text/javascript">
   
window.onload = function () {
    
    @if(Session::has('success'))
        var message = Session::get('success');
        toastr.success(message);
     @endif
    }
    
</script>-->

@endsection

@section('content')
<section class="section section-sm">
    <div class="container">

        <div class="row justify-content-center text-center mb-sm">
            <div class="col-lg-12 py-5">

                @if(Session::has('error'))
                <div class="alert alert-danger">
                    {{ Session::get('error') }}
                </div>

                @endif

                <h2 class="mb-0 text-break">{{trans('general.my_events')}}</h2>
                <p class="lead text-muted mt-0">

                </p>
                @if(Session::has('success'))
                <p>{{ Session::get('success') }}</p>
                @endif



            </div>
        </div>

        <div class="row">

            @if (auth()->check())
            @foreach($events as $response)
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card card-updates h-100">
                    <div class="card-cover" style="background: @if ($response->event_img != '') url({{ Helper::getFile(config('path.event').$response->event_img) }}) @else url({{url('/public/uploads/default-event-image/', $settings->event_default_image)}}) @endif #505050 center center; background-size: cover;">

                        <span class="badge-free px-2 py-1 text-uppercase position-absolute rounded">
                            @if($response->event_cost == 'free')

                            {{$response->event_cost}}

                            @else
                            {{Helper::amountFormatDecimal($response->event_price)}}
                            @endif
                            
                        </span>

                    </div>

                    <div class="card-body card-body-event">


                        <?php
                  //      echo date('Y-m-d H:i');
//                        echo '<br>';
//                        echo $parsed_date->diffInMinutes(); 
                        ?>
                        <h6 class="m-0 pb-1 text-muted card-text">
                            <i class="fa fa-calendar-alt mr-1" aria-hidden="true"></i>  {{ $response->start_date }}
                        </h6>

                        <h6 class="m-0 pb-1 text-muted card-text">
                            <i class="fa fa-clock mr-1" aria-hidden="true"></i> {{ $response->end_date }} hours
                        </h6>


                        <h6 class="m-0 pb-1 text-muted card-text">
                            <i class="fa fa-user mr-1" aria-hidden="true"></i>  {{ $response->event_name }}
                        </h6> 
                        <h6 class="m-0 pb-1 text-muted card-text">
                            <i class="fa fa-globe mr-1" aria-hidden="true"></i>  {{ $response->event_type }}
                        </h6>


                        <h6 class="m-0 py-1 text-muted card-text">
                            <i class="fa fa-map-marker-alt mr-1" aria-hidden="true"></i>  {{ $response->event_place }}
                        </h6>

                        <div id="showCountedInterest_{{$response->id}}">
                            @foreach (DB::table('event_interest')->select('interest', DB::raw('count(interest) as count'))->where('event_id', $response->id)->where('event_user_id', $response->user_id)->groupBy('interest')->get() as $event_interest)
                            <small class="m-0  pb-3 text-muted card-text">
                                @if($event_interest->interest == 'interested')
                                <i class="fa fa-circle pb-3" aria-hidden="true" style="font-size: 4px;"></i>
                                {{$event_interest->count}} {{trans('general.interested')}} @endif



                                @if($event_interest->interest == 'going')
                                <i class="fa fa-circle pb-3" aria-hidden="true" style="font-size: 4px;"></i>
                                {{ $event_interest->count }} {{trans('general.going')}}  @endif 

                            </small>
                            @endforeach
                        </div>



                        @php
                        $parsed_date = \Carbon\Carbon::parse($response->start_date);
                        if ($parsed_date->diffInMinutes() <= 15 || ($response->start_date <= date('Y-m-d H:i') && $response->duration >= date('Y-m-d H:i'))) {
                        $display = '';
                        }else {

                        $display = 'disabled';
                        }
                        
                        if($response->duration >= date("Y-m-d H:i")){
                        $show = '';
                        }else {
                        $show = 'none';
                        }

                        @endphp


                        <a href="{{url('/eventLiveStreaming/'.$response->id)}}"  style="float:left;display:{{$show}}" class="card-event">
                            <button id="start-event-btn" class="btn btn-primary mt-2" {{$display}}> START Event </button>
                        </a>

                        @php

                        if($response->duration >= date("Y-m-d H:i")){
                        $show = '';
                        }else {
                        $show = 'none';
                        }
                        @endphp

                        @if (auth()->user()->verified_id == 'yes')
                        <!--                        <button class="btn btn-google mt-1" title="{{trans('general.share')}}" id="dropdownUserShare" role="button" data-toggle="modal" data-target=".share-modal" style="float:right;display:{{$show}}">-->
                        <button class="btn btn-google mt-1 card-btn" title="{{trans('general.share')}}" id="dropdownUserShare" role="button" onclick="shareEvent('{{$response->id}}','{{ e( auth()->user()->hide_name == 'yes' ? auth()->user()->username : auth()->user()->name ) }}')" style="float:right;display:{{$show}}">
                            <i class="far fa-share-square mr-1 mr-lg-0"></i> 
<!--                            <span class="d-lg-none">{{trans('general.share')}}</span>-->
                        </button>

                        @endif

                    </div>
                </div><!-- End Card -->

            </div><!-- end col-md-4 -->
            @endforeach

            <!-- Share modal -->

            <div class="modal fade share-modal" id="share-event-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="mySmallModalLabel">{{trans('general.share')}}</h5>
                            <button type="button" class="close close-inherit" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true"><i class="fa fa-times-circle"></i></span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-4 col-6 mb-3">
                                        <a href="https://www.facebook.com/sharer/sharer.php?u={{url('events/1')}}" id="facebook_href" title="Facebook" target="_blank" class="social-share text-muted d-block text-center h6">
                                            <i class="fab fa-facebook-square facebook-btn"></i>
                                            <span class="btn-block mt-3">Facebook</span>
                                        </a>
                                    </div>
                                    <div class="col-md-4 col-6 mb-3">
                                        <a href="https://twitter.com/intent/tweet?url={{url('events/1')}}&text={{ e( auth()->user()->hide_name == 'yes' ? auth()->user()->username : auth()->user()->name ) }}" data-url="{{url('events/1')}}" id="twitter_href" class="social-share text-muted d-block text-center h6" target="_blank" title="Twitter">
                                            <i class="fab fa-twitter twitter-btn"></i> <span class="btn-block mt-3">Twitter</span>
                                        </a>
                                    </div>
                                    <div class="col-md-4 col-6 mb-3">
                                        <a href="whatsapp://send?text={{url('events/1')}}" data-action="share/whatsapp/share" id="whatsapp_href" class="social-share text-muted d-block text-center h6" title="WhatsApp">
                                            <i class="fab fa-whatsapp btn-whatsapp"></i> <span class="btn-block mt-3">WhatsApp</span>
                                        </a>
                                    </div>

                                    <div class="col-md-4 col-6 mb-3">
                                        <a href="mailto:?subject={{ e( auth()->user()->hide_name == 'yes' ? auth()->user()->username : auth()->user()->name ) }}&amp;body={{url('events/1')}}" id="mail_href" class="social-share text-muted d-block text-center h6" title="{{trans('auth.email')}}">
                                            <i class="far fa-envelope"></i> <span class="btn-block mt-3">{{trans('auth.email')}}</span>
                                        </a>
                                    </div>
                                    <div class="col-md-4 col-6 mb-3">
                                        <a href="sms://?body={{ trans('general.check_this') }} {{url('events/1')}}" id="sms_href" class="social-share text-muted d-block text-center h6" title="{{ trans('general.sms') }}">
                                            <i class="fa fa-sms"></i> <span class="btn-block mt-3">{{ trans('general.sms') }}</span>
                                        </a>
                                    </div>
                                    <div class="col-md-4 col-6 mb-3">
                                        <a href="javascript:void(0);" id="btn_copy_url" class="social-share text-muted d-block text-center h6 link-share" title="{{trans('general.copy_link')}}">
                                            <i class="fas fa-link"></i> <span class="btn-block mt-3">{{trans('general.copy_link')}}</span>
                                        </a>
                                        <input type="hidden" readonly="readonly" id="copy_link" class="form-control" value="{{url('events/1')}}">
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- Share modal end -->

            @endif


        </div>
    </div>
</section>
@endsection
